﻿namespace OOP_lab3.viewmodel
{
    public class ProfileViewModel
    {
        
    }
}