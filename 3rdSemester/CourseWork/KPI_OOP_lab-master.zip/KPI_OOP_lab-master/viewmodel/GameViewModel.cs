﻿using OOP_lab3.core;
using OOP_lab3.model;

namespace OOP_lab3.viewmodel
{
    public class GameViewModel : ObservableObj
    {
        public GameViewModel() 
        {
        }
    }
}