﻿namespace OOP_lab3.model.DTO
{
    public class Player_DTO
    {
        protected Account playerAccount;
    }
}