﻿namespace OOP_lab3.model.DTO
{
    public class HistoryNote_DTO
    {
        public int gameID { get; protected set; }
        public int maxlevelofgame { get; protected set; }
        public int countoflives { get; protected set; }
    }
}