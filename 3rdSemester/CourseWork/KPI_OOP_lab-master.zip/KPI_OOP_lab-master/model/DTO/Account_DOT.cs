﻿using System.Collections.Generic;

namespace OOP_lab3.model.DTO
{
    public class Account_DTO
    {
        public string login { get; protected set;}
        public string password { get; protected set;}
        public string nickname { get; protected set;}
        public int GamesCount { get; protected set; }
        
    }
}