﻿namespace OOP_lab3.model.Enum
{
    public enum MovementDirection
    {
        Up = 1,
        Down = 2,
        Left = 3,
        Right = 4,
    };

}